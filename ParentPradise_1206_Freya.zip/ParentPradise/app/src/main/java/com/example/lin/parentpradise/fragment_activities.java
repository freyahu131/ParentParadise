package com.example.lin.parentpradise;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


/**
 * Created by lin on 2017/12/4.
 */

public class fragment_activities extends Fragment {

    RadioGroup radioGroup2;
    RadioButton list, history, watch;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_activities, container, false);
        findviews();
        initContent();

        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                Fragment fragment;
                rbDefault();
                switch (checkedId)
                {
                    case R.id.list:
                        fragment = new fragment_activities_list();
                        switchFragment(fragment);
                        list.setTextColor(Color.WHITE);
                        break;
                    case R.id.history:
                        fragment = new fragment_activities_history();
                        switchFragment(fragment);
                        history.setTextColor(Color.WHITE);
                        break;
                    case R.id.watch:
                        fragment = new fragment_activities_watch();
                        switchFragment(fragment);
                        watch.setTextColor(Color.WHITE);
                        break;
                    default:
                        break;
                }
            }
        });
        return view;
    }

    private void findviews(){
        radioGroup2 = view.findViewById(R.id.radioGroup2);
        list = view.findViewById(R.id.list);
        history = view.findViewById(R.id.history);
        watch = view.findViewById(R.id.watch);
    }

    private void rbDefault(){
        list.setTextColor(Color.BLACK);
        history.setTextColor(Color.BLACK);
        watch.setTextColor(Color.BLACK);
    }

    private void initContent() {
        list.setTextColor(Color.WHITE);
        Fragment fragment = new fragment_activities_list();
        switchFragment(fragment);

    }

    private void switchFragment(Fragment fragment) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.content_activities, fragment);
        fragmentTransaction.commit();
    }
}
