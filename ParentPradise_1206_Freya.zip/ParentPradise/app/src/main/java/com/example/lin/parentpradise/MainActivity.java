package com.example.lin.parentpradise;



import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup1;
    RadioButton home, activities, share, community, favorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findviews();
        initContent();

        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                Fragment fragment;
                rbDefault();
                switch (checkedId)
                {
                    case R.id.home:
                        fragment = new fragment_home();
                        switchFragment(fragment);
                        setTitle("首頁");
                        home.setTextColor(Color.WHITE);
                        break;
                    case R.id.activities:
                        fragment = new fragment_activities();
                        switchFragment(fragment);
                        setTitle("活動");
                        activities.setTextColor(Color.WHITE);
                        break;
                    case R.id.share:
                        fragment = new fragment_share();
                        switchFragment(fragment);
                        setTitle("分享");
                        share.setTextColor(Color.WHITE);
                        break;
                    case R.id.community:
                        fragment = new fragment_community();
                        switchFragment(fragment);
                        setTitle("聊天");
                        community.setTextColor(Color.WHITE);
                        break;
                    case R.id.favorite:
                        fragment = new fragment_favorite();
                        switchFragment(fragment);
                        setTitle("收藏");
                        favorite.setTextColor(Color.WHITE);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    private void findviews(){
        radioGroup1=findViewById(R.id.radioGroup1);
        home = findViewById(R.id.home);
        activities = findViewById(R.id.activities);
        share = findViewById(R.id.share);
        community = findViewById(R.id.community);
        favorite = findViewById(R.id.favorite);
    }

    private void rbDefault(){
        home.setTextColor(Color.BLACK);
        activities.setTextColor(Color.BLACK);
        share.setTextColor(Color.BLACK);
        community.setTextColor(Color.BLACK);
        favorite.setTextColor(Color.BLACK);
    }

    private void initContent() {
        Fragment fragment = new fragment_home();
        switchFragment(fragment);
        setTitle("首頁");
        home.setTextColor(Color.WHITE);
    }

    private void switchFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.content, fragment);
        fragmentTransaction.commit();
    }

}
